/* global uibuilder */
'use strict';

const $ = (id) => document.getElementById(id);
const $$ = (selector) => Array.from(document.querySelectorAll(selector));

const state = {
  authMode: 'login',
  username: localStorage.getItem('nongtrai_username') || '',
  rooms: [],
  roomDevices: [],
  selectedRoomId: localStorage.getItem('nongtrai_room_id') || '',
  selectedDeviceId: localStorage.getItem('nongtrai_device_id') || '',
  latestSensor: {},
  latestSensorByDevice: {},
  latestGatewayStatus: {},
  pendingModes: {},
  devUnlocked: sessionStorage.getItem('nongtrai_dev_unlocked') === '1',
  relays: Array(10).fill(0),
  mode: '--',
  cfgVersion: '--',
  logs: [],
  uibReady: false,
  lastHistory: [],
  lastUsage: null,
};

const pageMeta = {
  pageOverview: ['Tổng quan', 'Xem nhanh dữ liệu theo từng phòng.'],
  pageRooms: ['Phòng / thiết bị', 'Quản lý phòng, tủ điều khiển và thiết bị đa cảm biến Fuviair.'],
  pageControl: ['Điều khiển tủ', 'Điều khiển relay, cài lịch và điều kiện tự động theo phòng.'],
  pageUsage: ['Điện & thống kê', 'Tổng điện năng và giá trị cảm biến theo ngày, tháng, năm.'],
  pageDev: ['Kỹ thuật', 'Lệnh hệ thống, lịch sử và log dành cho kỹ thuật viên.'],
};

function nowText() {
  return new Date().toLocaleTimeString('vi-VN', { hour12: false });
}

function num(v, digits = 1) {
  const n = Number(v);
  if (!Number.isFinite(n)) return '--';
  return String(Math.round(n * 10 ** digits) / 10 ** digits);
}

function intVal(v, fallback = 0) {
  const n = parseInt(v, 10);
  return Number.isFinite(n) ? n : fallback;
}

function floatVal(v, fallback = 0) {
  const n = parseFloat(v);
  return Number.isFinite(n) ? n : fallback;
}

function getGatewayId() {
  const selectedRoom = state.rooms.find(r => roomKey(r) === state.selectedRoomId);
  const roomGw = selectedRoom ? roomGatewayId(selectedRoom) : '';
  const gw = roomGw || $('gatewayId')?.value?.trim();
  return gw || 'ESP79';
}

function makeMsgId(prefix) {
  return `${prefix}_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
}

function showToast(text, type = 'ok') {
  const box = $('toastBox');
  if (!box) return;
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = text;
  box.appendChild(el);
  setTimeout(() => el.remove(), 3600);
}

function log(title, data) {
  const line = `[${nowText()}] ${title}${data !== undefined ? '\n' + safeJson(data) : ''}`;
  state.logs.unshift(line);
  state.logs = state.logs.slice(0, 160);
  const logBox = $('logBox');
  if (logBox) logBox.textContent = state.logs.join('\n\n');
}

function safeJson(obj) {
  try { return JSON.stringify(obj, null, 2); }
  catch { return String(obj); }
}

function normalizePayload(payload) {
  if (typeof payload === 'string') {
    try { return JSON.parse(payload); } catch { return { raw: payload }; }
  }
  if (payload && typeof payload === 'object') return payload;
  return {};
}

function send(topic, payload = {}) {
  if (!window.uibuilder || typeof uibuilder.send !== 'function') {
    showToast('Chưa kết nối uibuilder, không gửi được lệnh.', 'err');
    log('UI send failed: uibuilder missing', { topic, payload });
    return false;
  }
  const msg = { topic, payload };
  uibuilder.send(msg);
  log(`UI → Node-RED: ${topic}`, payload);
  return true;
}

function setBadge(online) {
  const badge = $('socketBadge');
  if (badge) {
    badge.className = `badge ${online ? 'good' : 'bad'}`;
    badge.textContent = online ? 'Online' : 'Offline';
  }
  if ($('webUiState')) $('webUiState').textContent = online ? 'Đang kết nối' : 'Mất kết nối';
}

function setAuthMode(mode) {
  state.authMode = mode;
  $('loginTab')?.classList.toggle('active', mode === 'login');
  $('registerTab')?.classList.toggle('active', mode === 'register');
  if ($('authSubmit')) $('authSubmit').textContent = mode === 'login' ? 'Đăng nhập' : 'Đăng ký';
  if ($('authStatus')) $('authStatus').textContent = mode === 'login' ? 'Nhập tài khoản để đăng nhập.' : 'Tạo tài khoản mới.';
}

function showApp() {
  $('authView')?.classList.add('hidden');
  $('appView')?.classList.remove('hidden');
  if ($('currentUserText')) $('currentUserText').textContent = state.username || '--';
  buildRelayControls();
  buildRelayMiniGrid();
  requestRooms();
  updateSelectedRoomDisplay();
  renderSystemDevices();
  updateDevView();
  requestStatus();
}

function showAuth() {
  $('appView')?.classList.add('hidden');
  $('authView')?.classList.remove('hidden');
}

function handleAuthSubmit(ev) {
  ev.preventDefault();
  const username = $('authUsername').value.trim();
  const password = $('authPassword').value;
  if (!username || !password) return;
  const topic = state.authMode === 'login' ? 'login_request' : 'register_request';
  if ($('authStatus')) $('authStatus').textContent = 'Đang gửi...';
  send(topic, { username, password });
}

function handleAuthResponse(payload) {
  const ok = payload?.status === 'success' || payload?.status === 'ok' || payload?.success === true;
  const message = payload?.message || (ok ? 'Thành công.' : 'Có lỗi.');
  if ($('authStatus')) $('authStatus').textContent = message;
  showToast(message, ok ? 'ok' : 'err');
  if (ok) {
    state.username = payload.username || $('authUsername')?.value?.trim() || state.username;
    localStorage.setItem('nongtrai_username', state.username);
    showApp();
  }
}

function logout() {
  localStorage.removeItem('nongtrai_username');
  state.username = '';
  showAuth();
}

function requestRooms() {
  if (!state.username) return;
  send('room_list_request', { username: state.username });
}

function roomKey(room) {
  return String(room.id ?? room.room_id ?? room.gateway_device_id ?? room.device_id ?? room.gateway_id ?? '').trim();
}

function roomGatewayId(room) {
  return String(room.gateway_id || room.gw_id || room.gateway || $('gatewayId')?.value || '').trim();
}

function devicesForRoom(room) {
  const rk = roomKey(room);
  const gw = roomGatewayId(room);
  const nested = Array.isArray(room.devices) ? room.devices : [];
  const flat = Array.isArray(state.roomDevices) ? state.roomDevices : [];
  return [...nested, ...flat.filter(d => String(d.room_id || d.roomId || '') === rk || String(d.gateway_id || '') === gw)];
}

function renderRooms() {
  const box = $('roomList');
  if (!box) return;
  box.innerHTML = '';
  if (!state.rooms.length) {
    box.className = 'room-list empty-list';
    box.textContent = 'Chưa có phòng.';
    renderDeviceSelects();
    renderRoomSelects();
    updateSelectedRoomDisplay();
    renderSystemDevices();
    return;
  }
  box.className = 'room-list';
  for (const room of state.rooms) {
    const rk = roomKey(room);
    const gw = roomGatewayId(room);
    const gatewayDeviceId = String(room.gateway_device_id || room.device_id || '').trim();
    const stm = String(room.stm_id || room.stm || '').trim();
    const name = room.room_name || room.name || rk || 'Không tên';
    const devices = devicesForRoom(room);
    const primarySensor = devices[0]?.id_device || devices[0]?.device_id || '';
    const active = (rk && rk === state.selectedRoomId) || (primarySensor && primarySensor === state.selectedDeviceId);
    const chips = devices.length ? `<div class="device-chip-list">${devices.map(d => `<span class="device-chip">${escapeHtml(d.id_device || d.device_id || '')}</span>`).join('')}</div>` : '<span class="room-meta">Chưa có thiết bị cảm biến trong phòng.</span>';
    const card = document.createElement('div');
    card.className = `room-card ${active ? 'active' : ''}`;
    card.innerHTML = `
      <div>
        <strong>${escapeHtml(name)}</strong>
        <span class="room-meta">Tủ: ${escapeHtml(gw || '--')} · STM: ${escapeHtml(stm || '--')}</span>
        ${chips}
      </div>
      <div class="room-actions">
        <button class="select-room" type="button">Chọn</button>
        <button class="delete-room" type="button">Xóa</button>
      </div>
    `;
    card.querySelector('.select-room').addEventListener('click', () => selectRoom(room));
    card.querySelector('.delete-room').addEventListener('click', () => deleteRoom(room));
    box.appendChild(card);
  }
  renderDeviceSelects();
  renderRoomSelects();
  updateSelectedRoomDisplay();
  renderSystemDevices();
}

function escapeHtml(v) {
  return String(v).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[ch]));
}

function selectRoom(room) {
  const rk = roomKey(room);
  const gw = roomGatewayId(room);
  if (gw && $('gatewayId')) $('gatewayId').value = gw;
  state.selectedRoomId = rk;
  if (rk) localStorage.setItem('nongtrai_room_id', rk);
  const devices = devicesForRoom(room);
  const firstSensor = devices[0]?.id_device || devices[0]?.device_id || '';
  if (firstSensor) selectDevice(firstSensor, false);
  renderRooms();
  renderRoomSelects();
  updateSelectedRoomDisplay();
  renderSystemDevices();
  requestStatus();
  showToast(`Đã chọn phòng ${room.room_name || room.name || rk}.`, 'ok');
}

function selectDevice(id, rerender = true) {
  state.selectedDeviceId = id || '';
  if (id) localStorage.setItem('nongtrai_device_id', id);
  if (rerender) {
    renderRooms();
    renderDeviceSelects();
  }
  showToast(`Đã chọn sensor ${id || '--'}.`, 'ok');
}

function deleteRoom(room) {
  const id = room.id;
  if (id === undefined || id === null || id === '') {
    showToast('Không thấy ID phòng để xóa.', 'err');
    return;
  }
  send('room_delete_request', { id, username: state.username });
}

function handleRoomForm(ev) {
  ev.preventDefault();
  const maTu = $('roomGatewayId')?.value?.trim() || getGatewayId();
  if ($('gatewayId')) $('gatewayId').value = maTu;
  send('room_create_request', {
    username: state.username,
    room_name: $('roomName').value.trim(),
    gateway_id: maTu,
    control_id: maTu,
    cabinet_id: maTu,
    stm_id: $('roomStmId')?.value?.trim() || 'STM79',
    gateway_device_id: maTu,
    device_id: maTu,
    device_key: $('roomDeviceKey').value.trim(),
  });
}

function handleRoomDeviceForm(ev) {
  ev.preventDefault();
  const sel = $('deviceRoomSelect');
  const selectedRoom = state.rooms.find(r => roomKey(r) === sel.value) || state.rooms[0] || {};
  const gateway_id = roomGatewayId(selectedRoom) || getGatewayId();
  send('room_device_add_request', {
    username: state.username,
    room_id: roomKey(selectedRoom),
    room_name: selectedRoom.room_name || selectedRoom.name || '',
    gateway_id,
    device_id: $('sensorDeviceIdInput').value.trim(),
    id_device: $('sensorDeviceIdInput').value.trim(),
    device_name: $('sensorDeviceNameInput').value.trim(),
    device_key: $('sensorDeviceKeyInput').value.trim(),
    fields: ['temperature', 'humidity', 'co2', 'light', 'voltage', 'current', 'frequency', 'power'],
  });
}

function requestRoomDevices() {
  if (!state.username) return;
  send('room_devices_list_request', { username: state.username, gateway_id: getGatewayId() });
}

function renderDeviceSelects() {
  const options = [];
  for (const r of state.rooms) {
    const roomName = r.room_name || r.name || '';
    const devs = devicesForRoom(r);
    for (const d of devs) {
      const id = String(d.id_device || d.device_id || '').trim();
      if (id) options.push({ id, name: `${roomName} - ${d.device_name || d.name || id}` });
    }
  }
  if (!options.length) {
    for (const r of state.rooms) {
      const id = String(r.id_device || '').trim();
      if (id) options.push({ id, name: r.room_name || r.name || id });
    }
  }

  if (!state.selectedDeviceId && options.length) {
    state.selectedDeviceId = options[0].id;
    localStorage.setItem('nongtrai_device_id', state.selectedDeviceId);
  }

  for (const sel of [$('sensorDeviceSelect'), $('historyDeviceSelect'), $('usageDeviceSelect')]) {
    if (!sel) continue;
    sel.innerHTML = '';
    if (!options.length) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'Chưa có thiết bị';
      sel.appendChild(opt);
      continue;
    }
    for (const item of options) {
      const opt = document.createElement('option');
      opt.value = item.id;
      opt.textContent = `${item.name} (${item.id})`;
      if (item.id === state.selectedDeviceId) opt.selected = true;
      sel.appendChild(opt);
    }
  }
}

function buildRelayMiniGrid() {
  const box = $('relayMiniGrid');
  if (!box) return;
  box.innerHTML = '';
  for (let i = 0; i < 10; i++) {
    const el = document.createElement('div');
    el.className = `relay-pill ${state.relays[i] ? 'on' : 'off'}`;
    el.id = `relayPill${i + 1}`;
    el.textContent = `K${i + 1}: ${state.relays[i] ? 'ON' : 'OFF'}`;
    box.appendChild(el);
  }
}

function buildRelayControls() {
  const box = $('relayControlGrid');
  if (!box) return;
  box.innerHTML = '';
  for (let i = 0; i < 10; i++) {
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.className = `relay-toggle ${state.relays[i] ? 'on' : 'off'}`;
    btn.id = `relayBtn${i + 1}`;
    btn.innerHTML = `<span>K${i + 1}</span><small>${state.relays[i] ? 'ON' : 'OFF'}</small>`;
    btn.addEventListener('click', () => sendRelay(i + 1, state.relays[i] ? 0 : 1));
    box.appendChild(btn);
  }
}

function updateRelayUi() {
  for (let i = 0; i < 10; i++) {
    const on = !!state.relays[i];
    const pill = $(`relayPill${i + 1}`);
    if (pill) {
      pill.className = `relay-pill ${on ? 'on' : 'off'}`;
      pill.textContent = `K${i + 1}: ${on ? 'ON' : 'OFF'}`;
    }
    const btn = $(`relayBtn${i + 1}`);
    if (btn) {
      btn.className = `relay-toggle ${on ? 'on' : 'off'}`;
      btn.innerHTML = `<span>K${i + 1}</span><small>${on ? 'ON' : 'OFF'}</small>`;
    }
  }
}

function setModeUi(mode) {
  if (!mode) return;
  const m = String(mode).trim().toUpperCase();
  state.mode = m;
  if ($('modeState')) $('modeState').textContent = modeLabel(m);
  $$('.mode-btn').forEach(btn => btn.classList.toggle('active', String(btn.dataset.mode || '').toUpperCase() === m));
}

function modeLabel(mode) {
  const m = String(mode || '').toUpperCase();
  return { MANUAL: 'Thủ công', TIMER: 'Hẹn giờ', SENSOR: 'Theo cảm biến' }[m] || mode || '--';
}

function sendMode(mode) {
  const m = String(mode || '').toUpperCase();
  const msgId = makeMsgId('UI_MODE');
  state.pendingModes[msgId] = m;
  setModeUi(m);
  send('mode_request', { msg_id: msgId, gateway_id: getGatewayId(), control_id: getGatewayId(), mode: m, ack_req: true });
}

function sendRelay(relay, value) {
  state.relays[relay - 1] = value ? 1 : 0;
  updateRelayUi();
  send('relay_request', {
    msg_id: makeMsgId(`UI_RELAY_${relay}`),
    gateway_id: getGatewayId(),
    control_id: getGatewayId(),
    relay,
    state: value ? 1 : 0,
    ack_req: true,
  });
}

function handleTimerForm(ev) {
  ev.preventDefault();
  send('timer_request', {
    msg_id: makeMsgId('UI_TIMER'),
    gateway_id: getGatewayId(),
    control_id: getGatewayId(),
    relay: intVal($('timerRelay').value, 1),
    index: intVal($('timerIndex').value, 1),
    enable: intVal($('timerEnable').value, 1),
    on: $('timerOn').value || '00:00',
    off: $('timerOff').value || '00:00',
    ack_req: true,
  });
}


function renderRoomSelects() {
  const selects = [$('deviceRoomSelect'), $('overviewRoomSelect'), $('controlRoomSelect')].filter(Boolean);
  for (const sel of selects) {
    sel.innerHTML = '';
    if (!state.rooms.length) {
      const opt = document.createElement('option');
      opt.value = '';
      opt.textContent = 'Chưa có phòng';
      sel.appendChild(opt);
      continue;
    }
    for (const room of state.rooms) {
      const opt = document.createElement('option');
      opt.value = roomKey(room);
      opt.textContent = `${room.room_name || room.name || roomKey(room)} - Tủ ${roomGatewayId(room) || '--'}`;
      if (opt.value === state.selectedRoomId) opt.selected = true;
      sel.appendChild(opt);
    }
  }
}

function handleSensorRuleForm(ev) {
  ev.preventDefault();
  const logic = $('sensorLogic').value;
  const payload = {
    msg_id: makeMsgId('UI_SENSOR_RULE'),
    gateway_id: getGatewayId(),
    control_id: getGatewayId(),
    relay: intVal($('sensorRelay').value, 1),
    enable: intVal($('sensorEnable').value, 1),
    id_device: $('sensorDeviceSelect').value || state.selectedDeviceId,
    field: $('sensorField').value,
    logic,
    ack_req: true,
  };
  if (logic === 'ABOVE') {
    payload.onAbove = floatVal($('sensorOnValue').value, 0);
    payload.offBelow = floatVal($('sensorOffValue').value, payload.onAbove - 5);
  } else {
    payload.onBelow = floatVal($('sensorOnValue').value, 0);
    payload.offAbove = floatVal($('sensorOffValue').value, payload.onBelow + 5);
  }
  send('sensor_rule_request', payload);
}

function requestStatus() {
  send('status_request', { gateway_id: getGatewayId(), control_id: getGatewayId() });
}

function requestFullState() {
  send('full_state_request', { gateway_id: getGatewayId(), control_id: getGatewayId() });
}

function sendFan() {
  send('fan_request', {
    msg_id: makeMsgId('UI_FAN'),
    gateway_id: getGatewayId(),
    control_id: getGatewayId(),
    fanMode: intVal($('fanModeInput').value, 1),
    ack_req: true,
  });
}

function sendFanThreshold() {
  send('fan_threshold_request', {
    msg_id: makeMsgId('UI_FAN_TH'),
    gateway_id: getGatewayId(),
    control_id: getGatewayId(),
    fanOnTemp: floatVal($('fanOnTempInput').value, 35),
    fanOffTemp: floatVal($('fanOffTempInput').value, 30),
    ack_req: true,
  });
}

function handleRawCmd() {
  try {
    const obj = JSON.parse($('rawCmdInput').value);
    obj.gateway_id = obj.gateway_id || getGatewayId();
    obj.control_id = obj.control_id || getGatewayId();
    obj.msg_id = obj.msg_id || makeMsgId('UI_RAW');
    send('stm32_cmd_request', obj);
  } catch (err) {
    showToast('Raw JSON không hợp lệ: ' + err.message, 'err');
  }
}

function handleHistoryForm(ev) {
  ev.preventDefault();
  send('history_request', {
    username: state.username,
    device_id: $('historyDeviceSelect').value || state.selectedDeviceId,
    type: $('historyType').value,
    filter: $('historyFilter').value,
  });
}

function todayLocalDate() {
  const d = new Date();
  const pad = n => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function initUsageDates() {
  const today = todayLocalDate();
  if ($('usageDate') && !$('usageDate').value) $('usageDate').value = today;
  if ($('usageMonth') && !$('usageMonth').value) $('usageMonth').value = today.slice(0, 7);
  if ($('usageYear') && !$('usageYear').value) $('usageYear').value = today.slice(0, 4);
  updateUsageDateInputs();
}

function updateUsageDateInputs() {
  const period = $('usagePeriod')?.value || 'day';
  $('usageDateWrap')?.classList.toggle('hidden', period !== 'day');
  $('usageMonthWrap')?.classList.toggle('hidden', period !== 'month');
  $('usageYearWrap')?.classList.toggle('hidden', period !== 'year');
}

function handleUsageForm(ev) {
  ev.preventDefault();
  const period = $('usagePeriod').value;
  let date = $('usageDate').value || todayLocalDate();
  if (period === 'month') date = $('usageMonth').value || todayLocalDate().slice(0, 7);
  if (period === 'year') date = $('usageYear').value || todayLocalDate().slice(0, 4);
  send('usage_request', {
    username: state.username,
    gateway_id: getGatewayId(),
    device_id: $('usageDeviceSelect').value || state.selectedDeviceId,
    metric: $('usageMetric').value,
    period,
    date,
    sample_sec: intVal($('usageSampleSec').value, 60),
    max_gap_sec: intVal($('usageMaxGapSec').value, 900),
  });
}

function handleIncoming(msg) {
  if (!msg || typeof msg !== 'object') return;
  log(`Node-RED → UI: ${msg.topic || '(no topic)'}`, msg.payload);
  const topic = msg.topic;
  const p = normalizePayload(msg.payload);

  switch (topic) {
    case 'auth_response':
      handleAuthResponse(p);
      break;
    case 'room_list_response':
      state.rooms = Array.isArray(p) ? p : (Array.isArray(p.rooms) ? p.rooms : []);
      if (Array.isArray(p.devices)) state.roomDevices = p.devices;
      renderRooms();
      requestRoomDevices();
      break;
    case 'room_devices_list_response':
      state.roomDevices = Array.isArray(p) ? p : (Array.isArray(p.devices) ? p.devices : []);
      renderRooms();
      break;
    case 'room_device_add_response':
      showToast(p?.message || 'Đã thêm sensor vào phòng.', p?.status === 'error' ? 'err' : 'ok');
      requestRoomDevices();
      break;
    case 'room_create_response':
    case 'room_delete_response':
      showToast(p?.message || (p?.status === 'success' ? 'Thành công.' : 'Đã nhận phản hồi.'), p?.status === 'error' ? 'err' : 'ok');
      requestRooms();
      break;
    case 'sensor_data':
    case 'nong_trai/sensors':
    case 'gateway_sensor':
      updateSensor(p || {});
      break;
    case 'history_response':
      state.lastHistory = Array.isArray(p) ? p : [];
      renderHistory();
      break;
    case 'usage_response':
      state.lastUsage = p || null;
      renderUsage();
      break;
    case 'gateway_status':
      updateGatewayStatus(p || {});
      break;
    case 'gateway_ack':
    case 'stm32_ack':
      handleAck(p || {});
      break;
    case 'stm32_status':
    case 'config_state':
    case 'full_state':
    case 'relay_state':
      updateStmState(topic, p || {});
      break;
    case 'fan_state':
      updateFanState(p || {});
      break;
    case 'stm32_boot':
      showToast('STM32 boot: ' + (p?.fw || 'OK'), 'ok');
      break;
    case 'gateway_device_request':
      showToast('ESP32 vừa hỏi Device List.', 'warn');
      break;
    case 'sync_request_from_stm32':
      showToast('STM32 yêu cầu sync config.', 'warn');
      break;
    default:
      // Cho các message chưa biết vẫn lưu log.
      break;
  }
}

function updateSensor(p) {
  const base = (p && typeof p.data === 'object' && p.data !== null) ? { ...p.data, ...p } : (p || {});
  const src = normalizePayload(base.payload || base);
  const did = String(src.device_id || src.id_device || src.idDevice || src.id || '').trim();
  if (did) state.latestSensorByDevice[did] = src;

  if (did && !state.selectedDeviceId) {
    state.selectedDeviceId = did;
    localStorage.setItem('nongtrai_device_id', did);
  }

  const shouldShow = !state.selectedRoomId || deviceBelongsToSelectedRoom(did) || !devicesForSelectedRoom().length;
  if (shouldShow) {
    state.latestSensor = src;
    const temperature = src.temperature ?? src.temp ?? src.t ?? src.Temperature;
    const humidity = src.humidity ?? src.humi ?? src.h ?? src.Humidity;
    const co2 = src.co2 ?? src.CO2 ?? src.Co2;
    const light = src.light ?? src.lux ?? src.Light;
    const voltage = src.voltage ?? src.volt ?? src.v;
    const current = src.current ?? src.amp ?? src.a;
    const frequency = src.frequency ?? src.freq ?? src.f;
    const power = src.power ?? src.watt ?? src.w;
    if ($('tempVal')) $('tempVal').textContent = num(temperature);
    if ($('humiVal')) $('humiVal').textContent = num(humidity);
    if ($('co2Val')) $('co2Val').textContent = num(co2, 0);
    if ($('lightVal')) $('lightVal').textContent = num(light, 0);
    if ($('voltageVal')) $('voltageVal').textContent = num(voltage);
    if ($('currentVal')) $('currentVal').textContent = num(current, 2);
    if ($('powerVal')) $('powerVal').textContent = num(power, 1);
    if ($('frequencyVal')) $('frequencyVal').textContent = num(frequency, 1);
  }
  renderSystemDevices();
}

function selectedRoom() {
  return state.rooms.find(r => roomKey(r) === state.selectedRoomId) || state.rooms[0] || null;
}

function devicesForSelectedRoom() {
  const r = selectedRoom();
  return r ? devicesForRoom(r) : [];
}

function deviceBelongsToSelectedRoom(deviceId) {
  if (!deviceId) return false;
  return devicesForSelectedRoom().some(d => String(d.id_device || d.device_id || '').trim() === String(deviceId).trim());
}

function updateSelectedRoomDisplay() {
  const r = selectedRoom();
  if (r && !state.selectedRoomId) state.selectedRoomId = roomKey(r);
  const name = r ? (r.room_name || r.name || roomKey(r)) : '--';
  const gw = r ? roomGatewayId(r) : getGatewayId();
  const stm = r ? (r.stm_id || r.stm || '--') : '--';
  const devices = r ? devicesForRoom(r) : [];
  const text = r ? `Phòng: ${name} · Tủ: ${gw || '--'} · STM: ${stm || '--'} · Cảm biến: ${devices.length}` : 'Chưa chọn phòng.';
  if ($('overviewRoomInfo')) $('overviewRoomInfo').textContent = text;
  if ($('controlRoomInfo')) $('controlRoomInfo').textContent = text;
  if ($('gatewayId') && gw) $('gatewayId').value = gw;
}

function renderSystemDevices() {
  const r = selectedRoom();
  const gw = r ? roomGatewayId(r) : getGatewayId();
  const devices = r ? devicesForRoom(r) : [];
  const lastGw = state.latestGatewayStatus || {};
  if ($('controlCabinetId')) $('controlCabinetId').textContent = gw || '--';
  if ($('controlCabinetState')) {
    const stateText = lastGw.state ? `${lastGw.state}${lastGw.ip ? ' · IP ' + lastGw.ip : ''}` : 'Chưa có trạng thái tủ.';
    $('controlCabinetState').textContent = stateText;
  }
  if ($('fuviairDeviceCount')) $('fuviairDeviceCount').textContent = String(devices.length);
  if ($('fuviairDeviceList')) {
    if (!devices.length) $('fuviairDeviceList').textContent = 'Chưa có thiết bị cảm biến.';
    else $('fuviairDeviceList').innerHTML = devices.map(d => {
      const id = escapeHtml(d.id_device || d.device_id || '');
      const online = state.latestSensorByDevice[d.id_device || d.device_id] ? ' · đã có dữ liệu' : '';
      return `<span class="device-chip">${id}${escapeHtml(online)}</span>`;
    }).join(' ');
  }
}

function updateGatewayStatus(p) {
  state.latestGatewayStatus = p || {};
  setBadge(String(p.state || '').toUpperCase() === 'ONLINE');
  renderSystemDevices();
}

function handleAck(p) {
  const ok = String(p.status || '').toUpperCase() === 'OK' || String(p.status || '').toUpperCase() === 'SUCCESS';
  const timeout = String(p.status || '').toUpperCase() === 'TIMEOUT';
  const ackFor = String(p.ack_for || '');
  if (ok && state.pendingModes[ackFor]) {
    setModeUi(p.mode || state.pendingModes[ackFor]);
    delete state.pendingModes[ackFor];
  }
  showToast(`${p.status || 'ACK'}: ${p.message || p.ack_for || ''}`, ok ? 'ok' : timeout ? 'warn' : 'err');
}

function updateStmState(topic, p) {
  const mode = p.mode || p.workMode || p.currentMode || p.data?.mode;
  if (mode) {
    setModeUi(mode);
  }
  if (p.cfgVersion !== undefined || p.cfg_version !== undefined) {
    state.cfgVersion = p.cfgVersion ?? p.cfg_version;
    if ($('cfgVersionState')) $('cfgVersionState').textContent = state.cfgVersion;
  }
  const cabinetTemp = p.cabinetTemp ?? p.cabinet_temp ?? p.tempCabinet ?? p.lm35;
  if (cabinetTemp !== undefined && $('cabinetTempState')) $('cabinetTempState').textContent = `${num(cabinetTemp)} °C`;
  if (p.emergency !== undefined && $('emergencyState')) $('emergencyState').textContent = truthy(p.emergency) ? 'ACTIVE' : 'OK';

  parseRelayState(topic, p);
  updateFanState(p);
}

function parseRelayState(topic, p) {
  if (Array.isArray(p.relays)) {
    p.relays.forEach((v, idx) => {
      if (idx < 10) state.relays[idx] = parseRelayValue(v);
    });
  }
  if (Array.isArray(p.relayState)) {
    p.relayState.forEach((v, idx) => {
      if (idx < 10) state.relays[idx] = parseRelayValue(v);
    });
  }
  if (Array.isArray(p.relay_state)) {
    p.relay_state.forEach((v, idx) => {
      if (idx < 10) state.relays[idx] = parseRelayValue(v);
    });
  }
  if (p.relay !== undefined && p.state !== undefined) {
    const idx = intVal(p.relay, 1) - 1;
    if (idx >= 0 && idx < 10) state.relays[idx] = parseRelayValue(p.state);
  }
  if (p.data && p.data.relay !== undefined && p.data.state !== undefined) {
    const idx = intVal(p.data.relay, 1) - 1;
    if (idx >= 0 && idx < 10) state.relays[idx] = parseRelayValue(p.data.state);
  }
  updateRelayUi();
}

function parseRelayValue(v) {
  if (typeof v === 'object' && v !== null) return parseRelayValue(v.state ?? v.value ?? v.on);
  return truthy(v) ? 1 : 0;
}

function truthy(v) {
  return v === true || v === 1 || v === '1' || String(v).toUpperCase() === 'ON' || String(v).toUpperCase() === 'TRUE' || String(v).toUpperCase() === 'ACTIVE';
}

function updateFanState(p) {
  if (!p || typeof p !== 'object') return;
  const fanMode = p.fanMode ?? p.fan_mode ?? p.fanModeRuntime ?? p.data?.fanMode;
  const fan = p.fan ?? p.fanRunning ?? p.fan_on ?? p.state;
  const fanText = fanMode !== undefined
    ? ['OFF', 'AUTO', 'ON'][Number(fanMode)] || String(fanMode)
    : fan !== undefined ? (truthy(fan) ? 'ON' : 'OFF') : null;
  if (fanText && $('fanState')) $('fanState').textContent = fanText;

  const cab = p.cabinetTemp ?? p.cabinet_temp;
  if (cab !== undefined && $('cabinetTempState')) $('cabinetTempState').textContent = `${num(cab)} °C`;
  if (p.fanOnTemp !== undefined && $('fanOnTempInput')) $('fanOnTempInput').value = p.fanOnTemp;
  if (p.fanOffTemp !== undefined && $('fanOffTempInput')) $('fanOffTempInput').value = p.fanOffTemp;
  if (fanMode !== undefined && $('fanModeInput')) $('fanModeInput').value = String(fanMode);
}


function metricUnit(metric) {
  return {
    energy_kwh: 'kWh',
    temperature: '°C',
    humidity: '%',
    co2: 'ppm',
    light: 'lux',
    voltage: 'V',
    current: 'A',
    frequency: 'Hz',
    power: 'W',
  }[metric] || '';
}

function renderUsage() {
  const data = state.lastUsage || {};
  const rows = Array.isArray(data.rows) ? data.rows : [];
  const summary = data.summary || {};
  const metric = data.metric || $('usageMetric')?.value || 'energy_kwh';
  const unit = data.unit || summary.unit || metricUnit(metric);
  const isEnergy = metric === 'energy_kwh';

  if ($('usageTotal')) $('usageTotal').textContent = isEnergy ? `${num(summary.total_kwh ?? summary.total ?? 0, 3)} ${unit}` : '--';
  if ($('usageAvg')) $('usageAvg').textContent = summary.avg !== undefined ? `${num(summary.avg, isEnergy ? 3 : 2)} ${unit}` : '--';
  if ($('usageMin')) $('usageMin').textContent = summary.min !== undefined ? `${num(summary.min, isEnergy ? 3 : 2)} ${unit}` : '--';
  if ($('usageMax')) $('usageMax').textContent = summary.max !== undefined ? `${num(summary.max, isEnergy ? 3 : 2)} ${unit}` : '--';
  if ($('usageCount')) $('usageCount').textContent = summary.count ?? rows.reduce((s, r) => s + (Number(r.count) || 0), 0) ?? '--';

  drawUsageChart(rows, unit);
  const box = $('usageTable');
  if (!box) return;
  if (!rows.length) {
    box.innerHTML = '<p class="muted">Không có dữ liệu trong khoảng đã chọn.</p>';
    return;
  }
  box.innerHTML = `
    <table>
      <thead><tr><th>Mốc thời gian</th><th>Giá trị</th><th>Min</th><th>Max</th><th>Số mẫu</th></tr></thead>
      <tbody>${rows.map(r => `<tr><td>${escapeHtml(r.time_label ?? '')}</td><td>${escapeHtml(num(r.value, isEnergy ? 4 : 2))} ${escapeHtml(unit)}</td><td>${r.min !== undefined ? escapeHtml(num(r.min, 2)) : '--'}</td><td>${r.max !== undefined ? escapeHtml(num(r.max, 2)) : '--'}</td><td>${escapeHtml(r.count ?? '')}</td></tr>`).join('')}</tbody>
    </table>
  `;
}

function drawUsageChart(data, unit = '') {
  drawSimpleChart('usageCanvas', data, unit);
}

function drawSimpleChart(canvasId, data, unit = '') {
  const canvas = $(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 700;
  const height = 260;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.clearRect(0, 0, width, height);

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = '#dbe9e4';
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    const y = 24 + i * ((height - 54) / 4);
    ctx.beginPath(); ctx.moveTo(44, y); ctx.lineTo(width - 16, y); ctx.stroke();
  }

  if (!Array.isArray(data) || data.length === 0) {
    ctx.fillStyle = '#687972';
    ctx.font = '14px system-ui';
    ctx.fillText('Không có dữ liệu', 24, 40);
    return;
  }

  const values = data.map(r => Number(r.value)).filter(Number.isFinite);
  if (!values.length) return;
  let min = Math.min(...values);
  let max = Math.max(...values);
  if (min === max) { min -= 1; max += 1; }

  const left = 44, right = width - 16, top = 20, bottom = height - 34;
  const xFor = i => left + (i / Math.max(1, data.length - 1)) * (right - left);
  const yFor = v => bottom - ((v - min) / (max - min)) * (bottom - top);

  ctx.strokeStyle = '#0f766e';
  ctx.lineWidth = 3;
  ctx.beginPath();
  data.forEach((r, i) => {
    const v = Number(r.value);
    if (!Number.isFinite(v)) return;
    const x = xFor(i), y = yFor(v);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = '#0f766e';
  data.forEach((r, i) => {
    const v = Number(r.value);
    if (!Number.isFinite(v)) return;
    ctx.beginPath(); ctx.arc(xFor(i), yFor(v), 4, 0, Math.PI * 2); ctx.fill();
  });

  ctx.fillStyle = '#687972';
  ctx.font = '12px system-ui';
  ctx.fillText(`${num(max, 2)} ${unit}`, 6, top + 5);
  ctx.fillText(`${num(min, 2)} ${unit}`, 6, bottom + 4);
  ctx.fillText(String(data[0].time_label || ''), left, height - 10);
  ctx.textAlign = 'right';
  ctx.fillText(String(data[data.length - 1].time_label || ''), right, height - 10);
  ctx.textAlign = 'left';
}

function renderHistory() {
  const data = state.lastHistory || [];
  drawHistoryChart(data);
  const box = $('historyTable');
  if (!box) return;
  if (!data.length) {
    box.innerHTML = '<p class="muted">Không có dữ liệu.</p>';
    return;
  }
  box.innerHTML = `
    <table>
      <thead><tr><th>Thời gian</th><th>Giá trị</th></tr></thead>
      <tbody>${data.map(r => `<tr><td>${escapeHtml(r.time_label ?? r.time ?? '')}</td><td>${escapeHtml(num(r.value, 2))}</td></tr>`).join('')}</tbody>
    </table>
  `;
}

function drawHistoryChart(data) {
  const canvas = $('historyCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  const ratio = window.devicePixelRatio || 1;
  const width = canvas.clientWidth || 700;
  const height = 260;
  canvas.width = width * ratio;
  canvas.height = height * ratio;
  ctx.setTransform(ratio, 0, 0, ratio, 0, 0);
  ctx.clearRect(0, 0, width, height);

  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);
  ctx.strokeStyle = '#dbe9e4';
  ctx.lineWidth = 1;
  for (let i = 0; i < 5; i++) {
    const y = 24 + i * ((height - 54) / 4);
    ctx.beginPath(); ctx.moveTo(44, y); ctx.lineTo(width - 16, y); ctx.stroke();
  }

  if (!Array.isArray(data) || data.length === 0) {
    ctx.fillStyle = '#687972';
    ctx.font = '14px system-ui';
    ctx.fillText('Không có dữ liệu', 24, 40);
    return;
  }

  const values = data.map(r => Number(r.value)).filter(Number.isFinite);
  if (!values.length) return;
  let min = Math.min(...values);
  let max = Math.max(...values);
  if (min === max) { min -= 1; max += 1; }

  const left = 44, right = width - 16, top = 20, bottom = height - 34;
  const xFor = i => left + (i / Math.max(1, data.length - 1)) * (right - left);
  const yFor = v => bottom - ((v - min) / (max - min)) * (bottom - top);

  ctx.strokeStyle = '#0f766e';
  ctx.lineWidth = 3;
  ctx.beginPath();
  data.forEach((r, i) => {
    const v = Number(r.value);
    if (!Number.isFinite(v)) return;
    const x = xFor(i), y = yFor(v);
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();

  ctx.fillStyle = '#0f766e';
  data.forEach((r, i) => {
    const v = Number(r.value);
    if (!Number.isFinite(v)) return;
    ctx.beginPath(); ctx.arc(xFor(i), yFor(v), 4, 0, Math.PI * 2); ctx.fill();
  });

  ctx.fillStyle = '#687972';
  ctx.font = '12px system-ui';
  ctx.fillText(num(max, 2), 6, top + 5);
  ctx.fillText(num(min, 2), 6, bottom + 4);
  ctx.fillText(String(data[0].time_label || ''), left, height - 10);
  ctx.textAlign = 'right';
  ctx.fillText(String(data[data.length - 1].time_label || ''), right, height - 10);
  ctx.textAlign = 'left';
}

function changePage(id) {
  $$('.page').forEach(p => p.classList.toggle('active', p.id === id));
  $$('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.page === id));
  const [title, sub] = pageMeta[id] || pageMeta.pageOverview;
  if ($('pageTitle')) $('pageTitle').textContent = title;
  if ($('pageSubtitle')) $('pageSubtitle').textContent = sub;
  if (id === 'pageDev') updateDevView();
}

function handleRoomSelectChange(value) {
  const room = state.rooms.find(r => roomKey(r) === value);
  if (room) selectRoom(room);
}

function updateDevView() {
  const unlocked = !!state.devUnlocked;
  $('devLoginPanel')?.classList.toggle('hidden', unlocked);
  $('devToolsContent')?.classList.toggle('hidden', !unlocked);
}

function handleDevLogin(ev) {
  ev.preventDefault();
  const u = $('devUsername')?.value?.trim() || '';
  const p = $('devPassword')?.value || '';
  if (u === 'dev_fuvitech' && p === 'fuvitech2026') {
    state.devUnlocked = true;
    sessionStorage.setItem('nongtrai_dev_unlocked', '1');
    if ($('devLoginStatus')) $('devLoginStatus').textContent = 'Đã mở khu vực kỹ thuật.';
    showToast('Đã đăng nhập kỹ thuật.', 'ok');
    updateDevView();
  } else {
    if ($('devLoginStatus')) $('devLoginStatus').textContent = 'Sai tài khoản hoặc mật khẩu kỹ thuật.';
    showToast('Sai tài khoản hoặc mật khẩu kỹ thuật.', 'err');
  }
}

function attachEvents() {
  $('loginTab')?.addEventListener('click', () => setAuthMode('login'));
  $('registerTab')?.addEventListener('click', () => setAuthMode('register'));
  $('authForm')?.addEventListener('submit', handleAuthSubmit);
  $('logoutBtn')?.addEventListener('click', logout);
  $('refreshRoomsBtn')?.addEventListener('click', requestRooms);
  $('getStatusBtn')?.addEventListener('click', requestStatus);
  $('getFullStateTopBtn')?.addEventListener('click', requestFullState);
  $('syncConfigBtn')?.addEventListener('click', () => send('sync_request', { gateway_id: getGatewayId(), control_id: getGatewayId() }));
  $('deviceListCmdBtn')?.addEventListener('click', () => send('device_list_cmd_request', { gateway_id: getGatewayId(), control_id: getGatewayId() }));
  $('roomForm')?.addEventListener('submit', handleRoomForm);
  $('roomDeviceForm')?.addEventListener('submit', handleRoomDeviceForm);
  $('timerForm')?.addEventListener('submit', handleTimerForm);
  $('sensorRuleForm')?.addEventListener('submit', handleSensorRuleForm);
  $('sendFanBtn')?.addEventListener('click', sendFan);
  $('sendFanThresholdBtn')?.addEventListener('click', sendFanThreshold);
  $('sendRawCmdBtn')?.addEventListener('click', handleRawCmd);
  $('historyForm')?.addEventListener('submit', handleHistoryForm);
  $('usageForm')?.addEventListener('submit', handleUsageForm);
  $('usagePeriod')?.addEventListener('change', updateUsageDateInputs);
  $('devLoginForm')?.addEventListener('submit', handleDevLogin);
  $('overviewRoomSelect')?.addEventListener('change', ev => handleRoomSelectChange(ev.target.value));
  $('controlRoomSelect')?.addEventListener('change', ev => handleRoomSelectChange(ev.target.value));
  $('clearLogsBtn')?.addEventListener('click', () => { state.logs = []; if ($('logBox')) $('logBox').textContent = ''; });
  $('allRelayOffBtn')?.addEventListener('click', () => {
    for (let i = 1; i <= 10; i++) sendRelay(i, 0);
  });

  $$('.nav-btn').forEach(btn => btn.addEventListener('click', () => changePage(btn.dataset.page)));
  $$('.mode-btn').forEach(btn => btn.addEventListener('click', () => sendMode(btn.dataset.mode)));
  $$('.quick-actions [data-quick]').forEach(btn => btn.addEventListener('click', () => send(btn.dataset.quick, { gateway_id: getGatewayId(), control_id: getGatewayId() })));

  $('sensorDeviceSelect')?.addEventListener('change', ev => selectDevice(ev.target.value));
  $('historyDeviceSelect')?.addEventListener('change', ev => selectDevice(ev.target.value));
  $('usageDeviceSelect')?.addEventListener('change', ev => selectDevice(ev.target.value));
  window.addEventListener('resize', () => { drawHistoryChart(state.lastHistory); if (state.lastUsage) drawUsageChart(state.lastUsage.rows || [], state.lastUsage.unit || ''); });
}

function startUibuilder() {
  if (!window.uibuilder) {
    $('uibuilderStatus')?.classList.remove('hidden');
    setBadge(false);
    log('Không tìm thấy uibuilder client. Kiểm tra đường dẫn script ../uibuilder/uibuilder.iife.min.js');
    return;
  }

  try {
    if (typeof uibuilder.start === 'function') uibuilder.start();
    state.uibReady = true;
    $('uibuilderStatus')?.classList.add('hidden');
    setBadge(true);
  } catch (err) {
    log('Lỗi start uibuilder', err.message || err);
  }

  if (typeof uibuilder.onChange === 'function') {
    uibuilder.onChange('msg', handleIncoming);
    uibuilder.onChange('ioConnected', val => setBadge(!!val));
  } else if (typeof uibuilder.on === 'function') {
    uibuilder.on('msg', handleIncoming);
    uibuilder.on('io connected', () => setBadge(true));
    uibuilder.on('io disconnected', () => setBadge(false));
  }
}

function init() {
  attachEvents();
  setAuthMode('login');
  buildRelayControls();
  buildRelayMiniGrid();
  renderDeviceSelects();
  initUsageDates();
  startUibuilder();
  updateDevView();

  if (state.username) showApp();
  else showAuth();
}

document.addEventListener('DOMContentLoaded', init);
