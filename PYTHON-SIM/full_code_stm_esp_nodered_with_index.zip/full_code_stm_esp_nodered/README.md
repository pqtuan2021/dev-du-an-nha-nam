# Full code STM, ESP, Node-RED

Bao gồm:
- `ESP32_NhaNam/src/main.cpp`: code ESP32 gateway cầu MQTT <-> UART
- `STM_NhaNam/src/main.cpp`: code STM32 điều khiển relay, timer, sensor rule, fan
- `NodeRED/flows_customer_ui_v9.json`: flow Node-RED hiện tại

Cấu hình ID hiện tại:
- CONTROL_ID / GW_ID: `ESP79`
- STM_ID: `STM79`
- Legacy FLOW2_DEVICE_ID: `ESP79001`

Ghi chú:
- Đây là bộ code hiện tại đã chỉnh hướng `ESP32 cầu + STM32 dùng chung ID tủ điều khiển`.
- File Node-RED là flow hiện tại để import trực tiếp vào Node-RED.
- Nếu cần refactor tiếp sang mô hình đầy đủ `Khu vực -> Tủ -> Thiết bị` ở cả DB/flow/UI thì cần làm thêm bước tiếp theo.
